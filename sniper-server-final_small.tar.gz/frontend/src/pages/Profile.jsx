import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { 
  User, 
  Mail,
  Lock,
  Shield,
  Bell,
  Eye,
  EyeOff,
  Save,
  Smartphone,
  Key,
  CheckCircle,
  AlertCircle,
  Crown
} from 'lucide-react'

const Profile = () => {
  const [showPassword, setShowPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  
  const [profile, setProfile] = useState({
    username: 'user123',
    email: 'user@example.com',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    twoFactorEnabled: false,
    emailNotifications: true,
    smsNotifications: false
  })

  const [accountStats] = useState({
    totalOrders: 47,
    completedOrders: 43,
    totalSpent: 1250.50,
    memberSince: '2024-06-15',
    lastLogin: '2025-01-11 17:30:25'
  })

  const handleSaveProfile = () => {
    // Handle profile update
    console.log('Saving profile:', profile)
  }

  const handleChangePassword = () => {
    // Handle password change
    console.log('Changing password')
  }

  const handleToggle2FA = () => {
    setProfile({ ...profile, twoFactorEnabled: !profile.twoFactorEnabled })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground mb-2">الملف الشخصي</h1>
        <p className="text-muted-foreground">إدارة معلومات حسابك وإعداداتك</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Information */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                المعلومات الأساسية
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">اسم المستخدم</Label>
                  <Input
                    id="username"
                    value={profile.username}
                    onChange={(e) => setProfile({ ...profile, username: e.target.value })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  />
                </div>
              </div>
              
              <Button onClick={handleSaveProfile}>
                <Save className="w-4 h-4 mr-2" />
                حفظ التغييرات
              </Button>
            </CardContent>
          </Card>

          {/* Change Password */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5" />
                تغيير كلمة المرور
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">كلمة المرور الحالية</Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    type={showPassword ? 'text' : 'password'}
                    value={profile.currentPassword}
                    onChange={(e) => setProfile({ ...profile, currentPassword: e.target.value })}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute left-2 top-1/2 transform -translate-y-1/2"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                  <div className="relative">
                    <Input
                      id="newPassword"
                      type={showNewPassword ? 'text' : 'password'}
                      value={profile.newPassword}
                      onChange={(e) => setProfile({ ...profile, newPassword: e.target.value })}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={profile.confirmPassword}
                      onChange={(e) => setProfile({ ...profile, confirmPassword: e.target.value })}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-yellow-700 dark:text-yellow-300 mb-1">متطلبات كلمة المرور:</p>
                    <ul className="text-yellow-600 dark:text-yellow-400 space-y-1">
                      <li>• على الأقل 8 أحرف</li>
                      <li>• تحتوي على أحرف كبيرة وصغيرة</li>
                      <li>• تحتوي على أرقام ورموز</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleChangePassword}
                disabled={!profile.currentPassword || !profile.newPassword || profile.newPassword !== profile.confirmPassword}
              >
                <Lock className="w-4 h-4 mr-2" />
                تغيير كلمة المرور
              </Button>
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                إعدادات الأمان
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Two Factor Authentication */}
              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Smartphone className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">المصادقة الثنائية</h3>
                    <p className="text-sm text-muted-foreground">
                      حماية إضافية لحسابك باستخدام تطبيق المصادقة
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={profile.twoFactorEnabled ? 'default' : 'secondary'}>
                    {profile.twoFactorEnabled ? 'مفعل' : 'غير مفعل'}
                  </Badge>
                  <Switch
                    checked={profile.twoFactorEnabled}
                    onCheckedChange={handleToggle2FA}
                  />
                </div>
              </div>

              {profile.twoFactorEnabled && (
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="font-medium text-green-700 dark:text-green-300">
                      المصادقة الثنائية مفعلة
                    </span>
                  </div>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    حسابك محمي بالمصادقة الثنائية. ستحتاج لرمز من تطبيق المصادقة عند تسجيل الدخول.
                  </p>
                  <Button variant="outline" size="sm" className="mt-3">
                    <Key className="w-4 h-4 mr-2" />
                    عرض رموز الاسترداد
                  </Button>
                </div>
              )}

              {/* Notification Settings */}
              <div className="space-y-4">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  إعدادات الإشعارات
                </h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium text-foreground">إشعارات البريد الإلكتروني</span>
                      <p className="text-sm text-muted-foreground">تلقي إشعارات عبر البريد الإلكتروني</p>
                    </div>
                    <Switch
                      checked={profile.emailNotifications}
                      onCheckedChange={(checked) => setProfile({ ...profile, emailNotifications: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium text-foreground">إشعارات الرسائل النصية</span>
                      <p className="text-sm text-muted-foreground">تلقي إشعارات عبر الرسائل النصية</p>
                    </div>
                    <Switch
                      checked={profile.smsNotifications}
                      onCheckedChange={(checked) => setProfile({ ...profile, smsNotifications: checked })}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Account Stats */}
        <div className="space-y-6">
          {/* Account Overview */}
          <Card className="glass-effect neon-glow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-primary" />
                نظرة عامة على الحساب
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <User className="w-10 h-10 text-primary" />
                </div>
                <h3 className="font-bold text-foreground">{profile.username}</h3>
                <p className="text-sm text-muted-foreground">{profile.email}</p>
                <Badge variant="secondary" className="mt-2">عضو نشط</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Account Statistics */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>إحصائيات الحساب</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">{accountStats.totalOrders}</div>
                  <div className="text-sm text-muted-foreground">إجمالي الطلبات</div>
                </div>
                
                <div className="text-center p-3 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-green-500">{accountStats.completedOrders}</div>
                  <div className="text-sm text-muted-foreground">طلبات مكتملة</div>
                </div>
              </div>

              <div className="text-center p-3 bg-muted rounded-lg">
                <div className="text-2xl font-bold text-yellow-500">{accountStats.totalSpent} جنيه</div>
                <div className="text-sm text-muted-foreground">إجمالي المصروفات</div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">عضو منذ:</span>
                  <span className="font-medium">{accountStats.memberSince}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">آخر دخول:</span>
                  <span className="font-medium">{accountStats.lastLogin}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>إجراءات سريعة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <Mail className="w-4 h-4 mr-2" />
                تغيير البريد الإلكتروني
              </Button>
              
              <Button variant="outline" className="w-full justify-start">
                <Shield className="w-4 h-4 mr-2" />
                سجل الأمان
              </Button>
              
              <Button variant="outline" className="w-full justify-start">
                <Key className="w-4 h-4 mr-2" />
                إدارة الجلسات
              </Button>
              
              <Button variant="destructive" className="w-full justify-start">
                <AlertCircle className="w-4 h-4 mr-2" />
                حذف الحساب
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Profile

