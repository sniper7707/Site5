import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Search, 
  Filter,
  Users, 
  Heart, 
  Share2, 
  Eye,
  MessageCircle,
  Instagram,
  Facebook,
  Youtube,
  Twitter,
  ShoppingCart
} from 'lucide-react'

const Services = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedPlatform, setSelectedPlatform] = useState('all')
  const [selectedType, setSelectedType] = useState('all')

  const services = [
    {
      id: 1,
      name: 'متابعين إنستغرام عرب حقيقيين',
      platform: 'Instagram',
      type: 'followers',
      icon: Users,
      platformIcon: Instagram,
      price: 15.00,
      minOrder: 100,
      maxOrder: 10000,
      status: 'متاح',
      quality: 'عالية الجودة',
      description: 'متابعين عرب حقيقيين بصور شخصية ونشاط طبيعي',
      deliveryTime: '0-1 ساعة',
      guarantee: '30 يوم'
    },
    {
      id: 2,
      name: 'لايكات فيسبوك سريعة',
      platform: 'Facebook',
      type: 'likes',
      icon: Heart,
      platformIcon: Facebook,
      price: 8.50,
      minOrder: 50,
      maxOrder: 5000,
      status: 'متاح',
      quality: 'جودة ممتازة',
      description: 'لايكات سريعة وآمنة لمنشوراتك على فيسبوك',
      deliveryTime: '0-30 دقيقة',
      guarantee: '15 يوم'
    },
    {
      id: 3,
      name: 'مشاهدات يوتيوب عالية الجودة',
      platform: 'YouTube',
      type: 'views',
      icon: Eye,
      platformIcon: Youtube,
      price: 12.00,
      minOrder: 1000,
      maxOrder: 100000,
      status: 'متاح',
      quality: 'مشاهدات حقيقية',
      description: 'مشاهدات حقيقية من مستخدمين نشطين',
      deliveryTime: '1-6 ساعات',
      guarantee: '60 يوم'
    },
    {
      id: 4,
      name: 'ريتويت تويتر',
      platform: 'Twitter',
      type: 'retweets',
      icon: Share2,
      platformIcon: Twitter,
      price: 20.00,
      minOrder: 10,
      maxOrder: 1000,
      status: 'متاح',
      quality: 'تفاعل طبيعي',
      description: 'ريتويت من حسابات حقيقية ونشطة',
      deliveryTime: '0-2 ساعة',
      guarantee: '30 يوم'
    },
    {
      id: 5,
      name: 'متابعين تويتر عرب',
      platform: 'Twitter',
      type: 'followers',
      icon: Users,
      platformIcon: Twitter,
      price: 25.00,
      minOrder: 50,
      maxOrder: 5000,
      status: 'متاح',
      quality: 'حسابات عربية',
      description: 'متابعين عرب حقيقيين بتفاعل طبيعي',
      deliveryTime: '1-3 ساعات',
      guarantee: '45 يوم'
    },
    {
      id: 6,
      name: 'لايكات إنستغرام سريعة',
      platform: 'Instagram',
      type: 'likes',
      icon: Heart,
      platformIcon: Instagram,
      price: 6.00,
      minOrder: 100,
      maxOrder: 10000,
      status: 'متاح',
      quality: 'سرعة عالية',
      description: 'لايكات سريعة وآمنة لمنشوراتك',
      deliveryTime: '0-15 دقيقة',
      guarantee: '30 يوم'
    },
    {
      id: 7,
      name: 'تعليقات إنستغرام عربية',
      platform: 'Instagram',
      type: 'comments',
      icon: MessageCircle,
      platformIcon: Instagram,
      price: 35.00,
      minOrder: 5,
      maxOrder: 100,
      status: 'متاح',
      quality: 'تعليقات مخصصة',
      description: 'تعليقات عربية مخصصة وذات معنى',
      deliveryTime: '1-6 ساعات',
      guarantee: '30 يوم'
    },
    {
      id: 8,
      name: 'مشاهدات فيسبوك',
      platform: 'Facebook',
      type: 'views',
      icon: Eye,
      platformIcon: Facebook,
      price: 10.00,
      minOrder: 1000,
      maxOrder: 50000,
      status: 'متاح',
      quality: 'مشاهدات حقيقية',
      description: 'مشاهدات حقيقية لفيديوهاتك على فيسبوك',
      deliveryTime: '1-12 ساعة',
      guarantee: '30 يوم'
    }
  ]

  const [orderForm, setOrderForm] = useState({
    serviceId: null,
    link: '',
    quantity: ''
  })

  const filteredServices = services.filter(service => {
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesPlatform = selectedPlatform === 'all' || service.platform === selectedPlatform
    const matchesType = selectedType === 'all' || service.type === selectedType
    return matchesSearch && matchesPlatform && matchesType
  })

  const calculatePrice = (service, quantity) => {
    if (!quantity || quantity < service.minOrder) return 0
    return ((quantity / 1000) * service.price).toFixed(2)
  }

  const handleOrder = (service) => {
    setOrderForm({ ...orderForm, serviceId: service.id })
  }

  const submitOrder = () => {
    // Handle order submission
    console.log('Order submitted:', orderForm)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground mb-2">خدماتنا المتاحة</h1>
        <p className="text-muted-foreground">اختر من بين مجموعة واسعة من الخدمات عالية الجودة</p>
      </div>

      {/* Filters */}
      <Card className="glass-effect">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">البحث</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="ابحث عن خدمة..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>المنصة</Label>
              <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر المنصة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المنصات</SelectItem>
                  <SelectItem value="Instagram">إنستغرام</SelectItem>
                  <SelectItem value="Facebook">فيسبوك</SelectItem>
                  <SelectItem value="YouTube">يوتيوب</SelectItem>
                  <SelectItem value="Twitter">تويتر</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>نوع الخدمة</Label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر النوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="followers">متابعين</SelectItem>
                  <SelectItem value="likes">لايكات</SelectItem>
                  <SelectItem value="views">مشاهدات</SelectItem>
                  <SelectItem value="comments">تعليقات</SelectItem>
                  <SelectItem value="retweets">ريتويت</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map((service) => {
          const Icon = service.icon
          const PlatformIcon = service.platformIcon
          return (
            <Card key={service.id} className="glass-effect hover:neon-glow transition-all">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{service.name}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <PlatformIcon className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{service.platform}</span>
                      </div>
                    </div>
                  </div>
                  <Badge variant="secondary">{service.status}</Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{service.description}</p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">السعر لكل 1000:</span>
                    <div className="font-bold text-primary">{service.price} جنيه</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">وقت التسليم:</span>
                    <div className="font-medium">{service.deliveryTime}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">الحد الأدنى:</span>
                    <div className="font-medium">{service.minOrder.toLocaleString()}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">الحد الأقصى:</span>
                    <div className="font-medium">{service.maxOrder.toLocaleString()}</div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Badge variant="outline">{service.quality}</Badge>
                  <span className="text-xs text-muted-foreground">ضمان {service.guarantee}</span>
                </div>

                <Button 
                  className="w-full" 
                  onClick={() => handleOrder(service)}
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  اطلب الآن
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Order Form Modal */}
      {orderForm.serviceId && (
        <Card className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md mx-4">
            <Card className="glass-effect">
              <CardHeader>
                <CardTitle>طلب خدمة جديدة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="link">الرابط</Label>
                  <Input
                    id="link"
                    placeholder="ضع رابط المنشور أو الحساب هنا"
                    value={orderForm.link}
                    onChange={(e) => setOrderForm({ ...orderForm, link: e.target.value })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="quantity">الكمية</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="أدخل الكمية المطلوبة"
                    value={orderForm.quantity}
                    onChange={(e) => setOrderForm({ ...orderForm, quantity: e.target.value })}
                  />
                </div>

                {orderForm.quantity && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex justify-between">
                      <span>التكلفة الإجمالية:</span>
                      <span className="font-bold text-primary">
                        {calculatePrice(
                          services.find(s => s.id === orderForm.serviceId),
                          parseInt(orderForm.quantity)
                        )} جنيه
                      </span>
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setOrderForm({ serviceId: null, link: '', quantity: '' })}
                  >
                    إلغاء
                  </Button>
                  <Button 
                    className="flex-1"
                    onClick={submitOrder}
                    disabled={!orderForm.link || !orderForm.quantity}
                  >
                    تأكيد الطلب
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </Card>
      )}
    </div>
  )
}

export default Services

