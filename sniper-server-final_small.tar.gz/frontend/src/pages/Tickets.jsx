import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  MessageSquare, 
  Plus,
  Search,
  Filter,
  Clock,
  CheckCircle,
  AlertCircle,
  MessageCircle,
  Paperclip,
  Send,
  User,
  Shield
} from 'lucide-react'

const Tickets = () => {
  const [showNewTicket, setShowNewTicket] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [newTicket, setNewTicket] = useState({
    subject: '',
    priority: 'Normal',
    message: ''
  })
  const [newMessage, setNewMessage] = useState('')

  const tickets = [
    {
      id: 1,
      subject: 'مشكلة في طلب المتابعين',
      status: 'Open',
      priority: 'High',
      createdAt: '2025-01-11 14:30:25',
      updatedAt: '2025-01-11 16:45:12',
      messagesCount: 3,
      lastMessage: 'سيتم حل المشكلة خلال 24 ساعة',
      isAdminReply: true
    },
    {
      id: 2,
      subject: 'استفسار عن أسعار الخدمات',
      status: 'Answered',
      priority: 'Normal',
      createdAt: '2025-01-10 10:15:30',
      updatedAt: '2025-01-10 11:20:45',
      messagesCount: 2,
      lastMessage: 'شكراً لكم على الرد السريع',
      isAdminReply: false
    },
    {
      id: 3,
      subject: 'طلب استرداد مبلغ',
      status: 'Awaiting Reply',
      priority: 'High',
      createdAt: '2025-01-09 16:45:20',
      updatedAt: '2025-01-09 17:30:15',
      messagesCount: 4,
      lastMessage: 'نحتاج لمزيد من التفاصيل',
      isAdminReply: true
    },
    {
      id: 4,
      subject: 'مشكلة تقنية في الموقع',
      status: 'Closed',
      priority: 'Low',
      createdAt: '2025-01-08 12:20:10',
      updatedAt: '2025-01-08 14:15:30',
      messagesCount: 5,
      lastMessage: 'تم حل المشكلة بنجاح',
      isAdminReply: true
    }
  ]

  const ticketMessages = {
    1: [
      {
        id: 1,
        message: 'مرحباً، لدي مشكلة في طلب المتابعين رقم #92536. لم يتم تسليم الطلب بعد مرور 24 ساعة.',
        isAdminReply: false,
        createdAt: '2025-01-11 14:30:25',
        attachment: null
      },
      {
        id: 2,
        message: 'مرحباً بك، نعتذر عن التأخير. سيتم مراجعة طلبك والرد عليك خلال ساعة.',
        isAdminReply: true,
        createdAt: '2025-01-11 15:15:40',
        attachment: null
      },
      {
        id: 3,
        message: 'تم مراجعة طلبك وسيتم حل المشكلة خلال 24 ساعة. شكراً لصبرك.',
        isAdminReply: true,
        createdAt: '2025-01-11 16:45:12',
        attachment: null
      }
    ]
  }

  const getStatusInfo = (status) => {
    switch (status) {
      case 'Open':
        return { label: 'مفتوح', variant: 'default', icon: MessageCircle, color: 'text-blue-500' }
      case 'Answered':
        return { label: 'تم الرد', variant: 'secondary', icon: CheckCircle, color: 'text-green-500' }
      case 'Awaiting Reply':
        return { label: 'في انتظار الرد', variant: 'outline', icon: Clock, color: 'text-yellow-500' }
      case 'Closed':
        return { label: 'مغلق', variant: 'destructive', icon: CheckCircle, color: 'text-gray-500' }
      default:
        return { label: status, variant: 'secondary', icon: AlertCircle, color: 'text-gray-500' }
    }
  }

  const getPriorityInfo = (priority) => {
    switch (priority) {
      case 'High':
        return { label: 'عالية', color: 'text-red-500', bg: 'bg-red-500/10' }
      case 'Normal':
        return { label: 'عادية', color: 'text-blue-500', bg: 'bg-blue-500/10' }
      case 'Low':
        return { label: 'منخفضة', color: 'text-green-500', bg: 'bg-green-500/10' }
      default:
        return { label: priority, color: 'text-gray-500', bg: 'bg-gray-500/10' }
    }
  }

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = 
      ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.id.toString().includes(searchTerm)
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleCreateTicket = () => {
    // Handle ticket creation
    console.log('Creating ticket:', newTicket)
    setShowNewTicket(false)
    setNewTicket({ subject: '', priority: 'Normal', message: '' })
  }

  const handleSendMessage = () => {
    // Handle sending message
    console.log('Sending message:', newMessage)
    setNewMessage('')
  }

  const stats = {
    total: tickets.length,
    open: tickets.filter(t => t.status === 'Open').length,
    answered: tickets.filter(t => t.status === 'Answered').length,
    awaiting: tickets.filter(t => t.status === 'Awaiting Reply').length
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">التذاكر والدعم الفني</h1>
          <p className="text-muted-foreground">تواصل معنا للحصول على المساعدة</p>
        </div>
        <Button onClick={() => setShowNewTicket(true)}>
          <Plus className="w-4 h-4 mr-2" />
          تذكرة جديدة
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <MessageSquare className="w-8 h-8 text-primary mx-auto mb-2" />
            <div className="text-2xl font-bold text-foreground">{stats.total}</div>
            <div className="text-sm text-muted-foreground">إجمالي التذاكر</div>
          </CardContent>
        </Card>
        
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <MessageCircle className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-500">{stats.open}</div>
            <div className="text-sm text-muted-foreground">مفتوحة</div>
          </CardContent>
        </Card>
        
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-500">{stats.answered}</div>
            <div className="text-sm text-muted-foreground">تم الرد</div>
          </CardContent>
        </Card>
        
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-yellow-500">{stats.awaiting}</div>
            <div className="text-sm text-muted-foreground">في الانتظار</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-1 space-y-4">
          {/* Filters */}
          <Card className="glass-effect">
            <CardContent className="p-4 space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث في التذاكر..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {['all', 'Open', 'Answered', 'Awaiting Reply', 'Closed'].map((status) => (
                  <Button
                    key={status}
                    variant={statusFilter === status ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setStatusFilter(status)}
                  >
                    {status === 'all' ? 'الكل' : getStatusInfo(status).label}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Tickets */}
          <div className="space-y-3">
            {filteredTickets.map((ticket) => {
              const statusInfo = getStatusInfo(ticket.status)
              const priorityInfo = getPriorityInfo(ticket.priority)
              const StatusIcon = statusInfo.icon
              
              return (
                <Card 
                  key={ticket.id}
                  className={`glass-effect cursor-pointer transition-all ${
                    selectedTicket === ticket.id ? 'border-primary neon-glow' : 'hover:border-primary/50'
                  }`}
                  onClick={() => setSelectedTicket(ticket.id)}
                >
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-bold text-foreground">#{ticket.id}</span>
                            <Badge variant={statusInfo.variant}>
                              <StatusIcon className="w-3 h-3 mr-1" />
                              {statusInfo.label}
                            </Badge>
                          </div>
                          <h3 className="font-semibold text-foreground text-sm">{ticket.subject}</h3>
                        </div>
                        <div className={`px-2 py-1 rounded text-xs font-medium ${priorityInfo.bg} ${priorityInfo.color}`}>
                          {priorityInfo.label}
                        </div>
                      </div>

                      <div className="text-xs text-muted-foreground">
                        <div className="flex items-center gap-2 mb-1">
                          <MessageCircle className="w-3 h-3" />
                          <span>{ticket.messagesCount} رسالة</span>
                        </div>
                        <div>آخر تحديث: {ticket.updatedAt}</div>
                      </div>

                      <div className="text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          {ticket.isAdminReply ? (
                            <Shield className="w-3 h-3 text-primary" />
                          ) : (
                            <User className="w-3 h-3" />
                          )}
                          <span className="truncate">{ticket.lastMessage}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Ticket Details */}
        <div className="lg:col-span-2">
          {selectedTicket ? (
            <Card className="glass-effect h-[600px] flex flex-col">
              <CardHeader className="border-b border-border">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      #{selectedTicket}
                      {(() => {
                        const ticket = tickets.find(t => t.id === selectedTicket)
                        const statusInfo = getStatusInfo(ticket.status)
                        const StatusIcon = statusInfo.icon
                        return (
                          <Badge variant={statusInfo.variant}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {statusInfo.label}
                          </Badge>
                        )
                      })()}
                    </CardTitle>
                    <p className="text-muted-foreground">
                      {tickets.find(t => t.id === selectedTicket)?.subject}
                    </p>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <div>تم الإنشاء: {tickets.find(t => t.id === selectedTicket)?.createdAt}</div>
                    <div>آخر تحديث: {tickets.find(t => t.id === selectedTicket)?.updatedAt}</div>
                  </div>
                </div>
              </CardHeader>

              {/* Messages */}
              <CardContent className="flex-1 overflow-y-auto p-4">
                <div className="space-y-4">
                  {ticketMessages[selectedTicket]?.map((message) => (
                    <div 
                      key={message.id}
                      className={`flex ${message.isAdminReply ? 'justify-start' : 'justify-end'}`}
                    >
                      <div className={`max-w-[80%] p-4 rounded-lg ${
                        message.isAdminReply 
                          ? 'bg-muted text-foreground' 
                          : 'bg-primary text-primary-foreground'
                      }`}>
                        <div className="flex items-center gap-2 mb-2">
                          {message.isAdminReply ? (
                            <Shield className="w-4 h-4" />
                          ) : (
                            <User className="w-4 h-4" />
                          )}
                          <span className="text-sm font-medium">
                            {message.isAdminReply ? 'فريق الدعم' : 'أنت'}
                          </span>
                          <span className="text-xs opacity-70">{message.createdAt}</span>
                        </div>
                        <p className="text-sm">{message.message}</p>
                        {message.attachment && (
                          <div className="mt-2 flex items-center gap-2 text-xs">
                            <Paperclip className="w-3 h-3" />
                            <span>{message.attachment}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>

              {/* Reply Form */}
              <div className="border-t border-border p-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="اكتب رسالتك هنا..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="flex-1"
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ) : (
            <Card className="glass-effect h-[600px] flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">اختر تذكرة</h3>
                <p className="text-muted-foreground">اختر تذكرة من القائمة لعرض التفاصيل</p>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* New Ticket Modal */}
      {showNewTicket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <Card className="w-full max-w-md mx-4 glass-effect">
            <CardHeader>
              <CardTitle>تذكرة جديدة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="subject">الموضوع</Label>
                <Input
                  id="subject"
                  placeholder="اكتب موضوع التذكرة"
                  value={newTicket.subject}
                  onChange={(e) => setNewTicket({ ...newTicket, subject: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>الأولوية</Label>
                <Select value={newTicket.priority} onValueChange={(value) => setNewTicket({ ...newTicket, priority: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">منخفضة</SelectItem>
                    <SelectItem value="Normal">عادية</SelectItem>
                    <SelectItem value="High">عالية</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">الرسالة</Label>
                <Textarea
                  id="message"
                  placeholder="اشرح مشكلتك أو استفسارك بالتفصيل"
                  value={newTicket.message}
                  onChange={(e) => setNewTicket({ ...newTicket, message: e.target.value })}
                  rows={4}
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setShowNewTicket(false)}
                >
                  إلغاء
                </Button>
                <Button 
                  className="flex-1"
                  onClick={handleCreateTicket}
                  disabled={!newTicket.subject || !newTicket.message}
                >
                  إنشاء التذكرة
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export default Tickets

