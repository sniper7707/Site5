import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { 
  CreditCard, 
  Banknote,
  Wallet,
  Copy,
  CheckCircle,
  Clock,
  AlertCircle,
  Upload,
  History
} from 'lucide-react'

const AddFunds = () => {
  const [selectedMethod, setSelectedMethod] = useState(null)
  const [amount, setAmount] = useState('')
  const [transactionId, setTransactionId] = useState('')
  const [notes, setNotes] = useState('')
  const [receipt, setReceipt] = useState(null)

  const paymentMethods = [
    {
      id: 'bank_transfer',
      name: 'تحويل بنكي',
      icon: Banknote,
      description: 'تحويل مباشر إلى الحساب البنكي',
      minAmount: 10,
      processingTime: '1-24 ساعة',
      fees: 'مجاني',
      accountDetails: {
        bankName: 'البنك الأهلي المصري',
        accountNumber: '01009462980',
        accountName: 'alaa badeeh',
        iban: 'EG380003000000000000000000000'
      }
    },
    {
      id: 'vodafone_cash',
      name: 'فودافون كاش',
      icon: CreditCard,
      description: 'دفع سريع عبر فودافون كاش',
      minAmount: 5,
      processingTime: '5-30 دقيقة',
      fees: 'مجاني',
      accountDetails: {
        number: '01009462980',
        name: 'alaa badeeh'
      }
    },
    {
      id: 'orange_money',
      name: 'أورانج موني',
      icon: CreditCard,
      description: 'دفع عبر أورانج موني',
      minAmount: 5,
      processingTime: '5-30 دقيقة',
      fees: 'مجاني',
      accountDetails: {
        number: '01009462980',
        name: 'alaa badeeh'
      }
    },
    {
      id: 'etisalat_cash',
      name: 'اتصالات كاش',
      icon: CreditCard,
      description: 'دفع عبر اتصالات كاش',
      minAmount: 5,
      processingTime: '5-30 دقيقة',
      fees: 'مجاني',
      accountDetails: {
        number: '01009462980',
        name: 'alaa badeeh'
      }
    }
  ]

  const recentDeposits = [
    {
      id: 'DEP001',
      amount: 100.00,
      method: 'فودافون كاش',
      status: 'Completed',
      date: '2025-01-11 15:30:25',
      transactionId: 'VF123456789'
    },
    {
      id: 'DEP002',
      amount: 50.00,
      method: 'تحويل بنكي',
      status: 'Pending',
      date: '2025-01-11 14:20:15',
      transactionId: 'BNK987654321'
    },
    {
      id: 'DEP003',
      amount: 75.00,
      method: 'أورانج موني',
      status: 'Completed',
      date: '2025-01-10 16:45:30',
      transactionId: 'OR456789123'
    }
  ]

  const getStatusInfo = (status) => {
    switch (status) {
      case 'Completed':
        return { label: 'مكتمل', variant: 'default', icon: CheckCircle, color: 'text-green-500' }
      case 'Pending':
        return { label: 'في الانتظار', variant: 'secondary', icon: Clock, color: 'text-yellow-500' }
      case 'Failed':
        return { label: 'فشل', variant: 'destructive', icon: AlertCircle, color: 'text-red-500' }
      default:
        return { label: status, variant: 'secondary', icon: AlertCircle, color: 'text-gray-500' }
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    // Show toast notification
  }

  const handleSubmit = () => {
    // Handle deposit submission
    console.log('Deposit submitted:', {
      method: selectedMethod,
      amount,
      transactionId,
      notes,
      receipt
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground mb-2">إضافة الأموال</h1>
        <p className="text-muted-foreground">أضف رصيد إلى حسابك لشراء الخدمات</p>
      </div>

      {/* Current Balance */}
      <Card className="glass-effect neon-glow">
        <CardContent className="p-6 text-center">
          <Wallet className="w-12 h-12 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">رصيدك الحالي</h2>
          <div className="text-4xl font-bold text-primary">0.00 جنيه</div>
          <p className="text-muted-foreground mt-2">آخر تحديث: اليوم 17:30</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Payment Methods */}
        <div className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>اختر طريقة الدفع</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {paymentMethods.map((method) => {
                const Icon = method.icon
                return (
                  <Card 
                    key={method.id}
                    className={`cursor-pointer transition-all border-2 ${
                      selectedMethod === method.id 
                        ? 'border-primary neon-glow' 
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => setSelectedMethod(method.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground">{method.name}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{method.description}</p>
                          <div className="grid grid-cols-3 gap-2 text-xs">
                            <div>
                              <span className="text-muted-foreground">الحد الأدنى:</span>
                              <div className="font-medium">{method.minAmount} جنيه</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">وقت المعالجة:</span>
                              <div className="font-medium">{method.processingTime}</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">الرسوم:</span>
                              <div className="font-medium text-green-500">{method.fees}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </CardContent>
          </Card>

          {/* Payment Details */}
          {selectedMethod && (
            <Card className="glass-effect">
              <CardHeader>
                <CardTitle>تفاصيل الدفع</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {(() => {
                  const method = paymentMethods.find(m => m.id === selectedMethod)
                  return (
                    <div className="space-y-3">
                      {method.id === 'bank_transfer' ? (
                        <>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">اسم البنك:</span>
                              <div className="font-medium flex items-center gap-2">
                                {method.accountDetails.bankName}
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => copyToClipboard(method.accountDetails.bankName)}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">رقم الحساب:</span>
                              <div className="font-medium flex items-center gap-2">
                                {method.accountDetails.accountNumber}
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => copyToClipboard(method.accountDetails.accountNumber)}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">اسم صاحب الحساب:</span>
                              <div className="font-medium">{method.accountDetails.accountName}</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">IBAN:</span>
                              <div className="font-medium flex items-center gap-2">
                                {method.accountDetails.iban}
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => copyToClipboard(method.accountDetails.iban)}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </>
                      ) : (
                        <div className="text-center p-4 bg-muted rounded-lg">
                          <div className="text-lg font-semibold text-foreground mb-2">
                            رقم المحفظة: {method.accountDetails.number}
                          </div>
                          <div className="text-sm text-muted-foreground mb-3">
                            باسم: {method.accountDetails.name}
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => copyToClipboard(method.accountDetails.number)}
                          >
                            <Copy className="w-4 h-4 mr-2" />
                            نسخ الرقم
                          </Button>
                        </div>
                      )}
                      
                      <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
                          <div className="text-sm">
                            <p className="font-medium text-yellow-700 dark:text-yellow-300 mb-1">تعليمات مهمة:</p>
                            <ul className="text-yellow-600 dark:text-yellow-400 space-y-1">
                              <li>• قم بالتحويل إلى البيانات المذكورة أعلاه فقط</li>
                              <li>• احتفظ بإيصال التحويل أو لقطة شاشة</li>
                              <li>• أدخل رقم العملية في النموذج أدناه</li>
                              <li>• سيتم إضافة الرصيد خلال {method.processingTime}</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })()}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Deposit Form */}
        <div className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>تأكيد الإيداع</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">المبلغ (جنيه)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="أدخل المبلغ"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  min={selectedMethod ? paymentMethods.find(m => m.id === selectedMethod)?.minAmount : 1}
                />
                {selectedMethod && amount && amount < paymentMethods.find(m => m.id === selectedMethod)?.minAmount && (
                  <p className="text-sm text-red-500">
                    الحد الأدنى للإيداع هو {paymentMethods.find(m => m.id === selectedMethod)?.minAmount} جنيه
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="transactionId">رقم العملية / المرجع</Label>
                <Input
                  id="transactionId"
                  placeholder="أدخل رقم العملية أو المرجع"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="receipt">إيصال التحويل (اختياري)</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                  <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">اسحب الملف هنا أو انقر للاختيار</p>
                  <Button variant="outline" size="sm">
                    اختيار ملف
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">ملاحظات (اختياري)</Label>
                <Textarea
                  id="notes"
                  placeholder="أي ملاحظات إضافية..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                />
              </div>

              <Button 
                className="w-full" 
                onClick={handleSubmit}
                disabled={!selectedMethod || !amount || !transactionId}
              >
                <CreditCard className="w-4 h-4 mr-2" />
                تأكيد الإيداع
              </Button>
            </CardContent>
          </Card>

          {/* Recent Deposits */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                آخر الإيداعات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentDeposits.map((deposit) => {
                  const statusInfo = getStatusInfo(deposit.status)
                  const StatusIcon = statusInfo.icon
                  
                  return (
                    <div key={deposit.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          deposit.status === 'Completed' ? 'bg-green-500/10' :
                          deposit.status === 'Pending' ? 'bg-yellow-500/10' : 'bg-red-500/10'
                        }`}>
                          <StatusIcon className={`w-4 h-4 ${statusInfo.color}`} />
                        </div>
                        <div>
                          <div className="font-medium text-foreground">{deposit.amount} جنيه</div>
                          <div className="text-sm text-muted-foreground">{deposit.method}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
                        <div className="text-xs text-muted-foreground mt-1">{deposit.date}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default AddFunds

