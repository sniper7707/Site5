import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  TrendingUp, 
  Users, 
  Heart, 
  Share2, 
  Eye,
  MessageCircle,
  Star,
  Zap
} from 'lucide-react'

const Home = () => {
  const [stats, setStats] = useState({
    totalOrders: 1247,
    completedOrders: 1198,
    activeUsers: 89,
    totalRevenue: 45670
  })

  const popularServices = [
    {
      id: 1,
      name: 'متابعين إنستغرام عرب',
      platform: 'Instagram',
      icon: Users,
      price: 15.00,
      minOrder: 100,
      maxOrder: 10000,
      status: 'متاح',
      quality: 'عالية الجودة'
    },
    {
      id: 2,
      name: 'لايكات فيسبوك حقيقية',
      platform: 'Facebook',
      icon: Heart,
      price: 8.50,
      minOrder: 50,
      maxOrder: 5000,
      status: 'متاح',
      quality: 'جودة ممتازة'
    },
    {
      id: 3,
      name: 'مشاهدات يوتيوب',
      platform: 'YouTube',
      icon: Eye,
      price: 12.00,
      minOrder: 1000,
      maxOrder: 100000,
      status: 'متاح',
      quality: 'مشاهدات حقيقية'
    },
    {
      id: 4,
      name: 'مشاركات تويتر',
      platform: 'Twitter',
      icon: Share2,
      price: 20.00,
      minOrder: 10,
      maxOrder: 1000,
      status: 'متاح',
      quality: 'تفاعل طبيعي'
    }
  ]

  const recentOrders = [
    { id: 92537, service: 'متابعين إنستغرام', quantity: 1000, status: 'مكتمل', progress: 100 },
    { id: 92536, service: 'لايكات فيسبوك', quantity: 500, status: 'قيد التنفيذ', progress: 75 },
    { id: 92535, service: 'مشاهدات يوتيوب', quantity: 5000, status: 'قيد التنفيذ', progress: 45 },
    { id: 92534, service: 'مشاركات تويتر', quantity: 100, status: 'مكتمل', progress: 100 }
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="text-center py-8">
        <h1 className="text-4xl font-bold text-foreground mb-4 animate-float">
          مرحباً بك في سيرفر القناص المتكامل
        </h1>
        <p className="text-lg text-muted-foreground mb-6">
          أفضل موقع لشحن متابعين ولايكات ومشاركات لجميع مواقع التواصل الاجتماعي
        </p>
        <div className="flex items-center justify-center gap-2 text-primary">
          <Star className="w-5 h-5 fill-current" />
          <span className="font-medium">صاحب السيرفر: 👑 alaa badeeh 👑</span>
          <Star className="w-5 h-5 fill-current" />
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass-effect neon-glow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الطلبات</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.totalOrders.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">+12% من الشهر الماضي</p>
          </CardContent>
        </Card>

        <Card className="glass-effect">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الطلبات المكتملة</CardTitle>
            <Zap className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{stats.completedOrders.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">معدل إنجاز 96%</p>
          </CardContent>
        </Card>

        <Card className="glass-effect">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المستخدمين النشطين</CardTitle>
            <Users className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">{stats.activeUsers}</div>
            <p className="text-xs text-muted-foreground">متصل الآن</p>
          </CardContent>
        </Card>

        <Card className="glass-effect">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الإيرادات</CardTitle>
            <TrendingUp className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">{stats.totalRevenue.toLocaleString()} جنيه</div>
            <p className="text-xs text-muted-foreground">هذا الشهر</p>
          </CardContent>
        </Card>
      </div>

      {/* Popular Services */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-primary" />
            الخدمات الأكثر طلباً
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {popularServices.map((service) => {
              const Icon = service.icon
              return (
                <Card key={service.id} className="border border-border hover:border-primary transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">{service.name}</h3>
                          <p className="text-sm text-muted-foreground">{service.platform}</p>
                        </div>
                      </div>
                      <Badge variant="secondary">{service.status}</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">السعر لكل 1000:</span>
                        <span className="font-medium text-primary">{service.price} جنيه</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">الحد الأدنى:</span>
                        <span>{service.minOrder.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">الحد الأقصى:</span>
                        <span>{service.maxOrder.toLocaleString()}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">{service.quality}</Badge>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Orders */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-primary" />
            آخر الطلبات
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="text-sm">
                    <div className="font-medium text-foreground">#{order.id}</div>
                    <div className="text-muted-foreground">{order.service}</div>
                  </div>
                  <div className="text-sm">
                    <div className="text-muted-foreground">الكمية:</div>
                    <div className="font-medium">{order.quantity.toLocaleString()}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-sm text-center">
                    <div className="text-muted-foreground">التقدم</div>
                    <div className="font-medium">{order.progress}%</div>
                  </div>
                  <Badge 
                    variant={order.status === 'مكتمل' ? 'default' : 'secondary'}
                    className={order.status === 'مكتمل' ? 'bg-green-500' : ''}
                  >
                    {order.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-effect hover:neon-glow transition-all cursor-pointer">
          <CardContent className="p-6 text-center">
            <ShoppingCart className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">تصفح الخدمات</h3>
            <p className="text-muted-foreground text-sm mb-4">اكتشف جميع خدماتنا المتاحة</p>
            <Button className="w-full">تصفح الآن</Button>
          </CardContent>
        </Card>

        <Card className="glass-effect hover:neon-glow transition-all cursor-pointer">
          <CardContent className="p-6 text-center">
            <CreditCard className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">إضافة رصيد</h3>
            <p className="text-muted-foreground text-sm mb-4">أضف أموال إلى حسابك</p>
            <Button className="w-full">إضافة الآن</Button>
          </CardContent>
        </Card>

        <Card className="glass-effect hover:neon-glow transition-all cursor-pointer">
          <CardContent className="p-6 text-center">
            <MessageSquare className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">الدعم الفني</h3>
            <p className="text-muted-foreground text-sm mb-4">تواصل معنا للمساعدة</p>
            <Button className="w-full">تواصل معنا</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Home

