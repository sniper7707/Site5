import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Shield, 
  Users, 
  Package, 
  CreditCard, 
  MessageSquare,
  Settings,
  BarChart3,
  TrendingUp,
  DollarSign,
  Activity,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  Edit,
  Trash2,
  Crown
} from 'lucide-react'

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('dashboard')

  // Mock data
  const stats = {
    totalUsers: 1247,
    activeOrders: 89,
    totalRevenue: 45670.50,
    pendingTickets: 12,
    todayOrders: 34,
    todayRevenue: 1250.75
  }

  const recentOrders = [
    { id: 92537, user: 'user123', service: 'متابعين إنستغرام', amount: 15.00, status: 'Completed' },
    { id: 92536, user: 'ahmed_m', service: 'لايكات فيسبوك', amount: 8.50, status: 'In Progress' },
    { id: 92535, user: 'sara_k', service: 'مشاهدات يوتيوب', amount: 60.00, status: 'Pending' },
    { id: 92534, user: 'mohamed_a', service: 'ريتويت تويتر', amount: 20.00, status: 'Completed' }
  ]

  const recentUsers = [
    { id: 1, username: 'user123', email: 'user@example.com', balance: 125.50, orders: 15, joinDate: '2025-01-10' },
    { id: 2, username: 'ahmed_m', email: 'ahmed@example.com', balance: 75.25, orders: 8, joinDate: '2025-01-09' },
    { id: 3, username: 'sara_k', email: 'sara@example.com', balance: 200.00, orders: 22, joinDate: '2025-01-08' }
  ]

  const pendingPayments = [
    { id: 'PAY001', user: 'user123', amount: 100.00, method: 'فودافون كاش', date: '2025-01-11 15:30' },
    { id: 'PAY002', user: 'ahmed_m', amount: 50.00, method: 'تحويل بنكي', date: '2025-01-11 14:20' },
    { id: 'PAY003', user: 'sara_k', amount: 75.00, method: 'أورانج موني', date: '2025-01-11 13:45' }
  ]

  const openTickets = [
    { id: 1, user: 'user123', subject: 'مشكلة في طلب المتابعين', priority: 'High', date: '2025-01-11 14:30' },
    { id: 2, user: 'ahmed_m', subject: 'استفسار عن الأسعار', priority: 'Normal', date: '2025-01-11 12:15' },
    { id: 3, user: 'sara_k', subject: 'طلب استرداد', priority: 'High', date: '2025-01-11 10:45' }
  ]

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Completed':
        return <Badge className="bg-green-500">مكتمل</Badge>
      case 'In Progress':
        return <Badge variant="secondary">قيد التنفيذ</Badge>
      case 'Pending':
        return <Badge variant="outline">في الانتظار</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'High':
        return <Badge variant="destructive">عالية</Badge>
      case 'Normal':
        return <Badge variant="secondary">عادية</Badge>
      case 'Low':
        return <Badge variant="outline">منخفضة</Badge>
      default:
        return <Badge variant="secondary">{priority}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <Shield className="w-8 h-8 text-primary" />
            لوحة التحكم الإدارية
          </h1>
          <p className="text-muted-foreground">إدارة شاملة لسيرفر القناص المتكامل</p>
          <div className="flex items-center gap-2 text-primary mt-2">
            <Crown className="w-4 h-4" />
            <span className="text-sm font-medium">مرحباً 👑 alaa badeeh 👑</span>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="dashboard">لوحة المعلومات</TabsTrigger>
          <TabsTrigger value="orders">الطلبات</TabsTrigger>
          <TabsTrigger value="users">المستخدمين</TabsTrigger>
          <TabsTrigger value="payments">المدفوعات</TabsTrigger>
          <TabsTrigger value="tickets">التذاكر</TabsTrigger>
          <TabsTrigger value="settings">الإعدادات</TabsTrigger>
        </TabsList>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="glass-effect neon-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">إجمالي المستخدمين</p>
                    <p className="text-2xl font-bold text-primary">{stats.totalUsers.toLocaleString()}</p>
                  </div>
                  <Users className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">الطلبات النشطة</p>
                    <p className="text-2xl font-bold text-blue-500">{stats.activeOrders}</p>
                  </div>
                  <Package className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">إجمالي الإيرادات</p>
                    <p className="text-2xl font-bold text-green-500">{stats.totalRevenue.toLocaleString()} جنيه</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">التذاكر المعلقة</p>
                    <p className="text-2xl font-bold text-yellow-500">{stats.pendingTickets}</p>
                  </div>
                  <MessageSquare className="w-8 h-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Today's Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-effect">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  إحصائيات اليوم
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">طلبات اليوم:</span>
                    <span className="font-bold text-primary">{stats.todayOrders}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">إيرادات اليوم:</span>
                    <span className="font-bold text-green-500">{stats.todayRevenue} جنيه</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">متوسط قيمة الطلب:</span>
                    <span className="font-bold text-blue-500">{(stats.todayRevenue / stats.todayOrders).toFixed(2)} جنيه</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  النشاط الأخير
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span>تم إكمال طلب #92537</span>
                    <span className="text-muted-foreground">منذ 5 دقائق</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Users className="w-4 h-4 text-blue-500" />
                    <span>مستخدم جديد: user456</span>
                    <span className="text-muted-foreground">منذ 12 دقيقة</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <CreditCard className="w-4 h-4 text-yellow-500" />
                    <span>إيداع جديد: 100 جنيه</span>
                    <span className="text-muted-foreground">منذ 18 دقيقة</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Orders */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>آخر الطلبات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div className="flex items-center gap-4">
                      <span className="font-medium">#{order.id}</span>
                      <span className="text-muted-foreground">{order.user}</span>
                      <span>{order.service}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-medium text-primary">{order.amount} جنيه</span>
                      {getStatusBadge(order.status)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders Tab */}
        <TabsContent value="orders" className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>إدارة الطلبات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold">#{order.id}</span>
                        {getStatusBadge(order.status)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        المستخدم: {order.user} | الخدمة: {order.service}
                      </div>
                      <div className="text-sm font-medium text-primary">{order.amount} جنيه</div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      {order.status === 'Pending' && (
                        <>
                          <Button size="sm" className="bg-green-500 hover:bg-green-600">
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button variant="destructive" size="sm">
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>إدارة المستخدمين</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="space-y-1">
                      <div className="font-semibold">{user.username}</div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                      <div className="text-sm">
                        الرصيد: <span className="font-medium text-primary">{user.balance} جنيه</span> | 
                        الطلبات: <span className="font-medium">{user.orders}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>المدفوعات المعلقة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold">{payment.id}</span>
                        <Badge variant="outline">في الانتظار</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        المستخدم: {payment.user} | الطريقة: {payment.method}
                      </div>
                      <div className="text-sm font-medium text-primary">{payment.amount} جنيه</div>
                      <div className="text-xs text-muted-foreground">{payment.date}</div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="bg-green-500 hover:bg-green-600">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        قبول
                      </Button>
                      <Button variant="destructive" size="sm">
                        <XCircle className="w-4 h-4 mr-2" />
                        رفض
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tickets Tab */}
        <TabsContent value="tickets" className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle>التذاكر المفتوحة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {openTickets.map((ticket) => (
                  <div key={ticket.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold">#{ticket.id}</span>
                        {getPriorityBadge(ticket.priority)}
                      </div>
                      <div className="font-medium">{ticket.subject}</div>
                      <div className="text-sm text-muted-foreground">
                        المستخدم: {ticket.user} | {ticket.date}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        عرض
                      </Button>
                      <Button size="sm">
                        <MessageSquare className="w-4 h-4 mr-2" />
                        رد
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                إعدادات الموقع
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">اسم الموقع</label>
                  <Input defaultValue="سيرفر القناص المتكامل" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">صاحب السيرفر</label>
                  <Input defaultValue="👑alaa badeeh 👑" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">الحد الأدنى للإيداع</label>
                  <Input defaultValue="10.00" type="number" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">العملة</label>
                  <Input defaultValue="EGP" />
                </div>
              </div>
              <Button>
                <Save className="w-4 h-4 mr-2" />
                حفظ الإعدادات
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default AdminPanel

