import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  FileText, 
  Shield, 
  AlertTriangle, 
  CheckCircle,
  Crown,
  Scale
} from 'lucide-react'

const Terms = () => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground mb-2">شروط الخدمة</h1>
        <p className="text-muted-foreground">اقرأ شروط وأحكام استخدام سيرفر القناص المتكامل</p>
        <div className="flex items-center justify-center gap-2 text-primary mt-4">
          <Crown className="w-5 h-5" />
          <span className="font-medium">صاحب السيرفر: 👑 alaa badeeh 👑</span>
          <Crown className="w-5 h-5" />
        </div>
      </div>

      {/* Terms Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Table of Contents */}
        <div className="lg:col-span-1">
          <Card className="glass-effect sticky top-6">
            <CardHeader>
              <CardTitle className="text-lg">المحتويات</CardTitle>
            </CardHeader>
            <CardContent>
              <nav className="space-y-2">
                <a href="#introduction" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  1. مقدمة
                </a>
                <a href="#services" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  2. الخدمات المقدمة
                </a>
                <a href="#user-obligations" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  3. التزامات المستخدم
                </a>
                <a href="#payments" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  4. الدفع والاسترداد
                </a>
                <a href="#prohibited" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  5. الاستخدامات المحظورة
                </a>
                <a href="#liability" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  6. المسؤولية
                </a>
                <a href="#privacy" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  7. الخصوصية
                </a>
                <a href="#changes" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  8. التعديلات
                </a>
                <a href="#contact" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  9. التواصل
                </a>
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Terms Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Introduction */}
          <Card id="introduction" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                1. مقدمة
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none dark:prose-invert">
              <p className="text-muted-foreground leading-relaxed">
                مرحباً بك في سيرفر القناص المتكامل، الموقع الرائد في تقديم خدمات التسويق الرقمي ومواقع التواصل الاجتماعي. 
                باستخدامك لهذا الموقع، فإنك توافق على الالتزام بهذه الشروط والأحكام. إذا كنت لا توافق على أي من هذه الشروط، 
                يرجى عدم استخدام خدماتنا.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                هذه الشروط تحكم استخدامك لجميع الخدمات المقدمة من خلال موقعنا، بما في ذلك شراء المتابعين، اللايكات، 
                المشاهدات، والتعليقات لمختلف منصات التواصل الاجتماعي.
              </p>
            </CardContent>
          </Card>

          {/* Services */}
          <Card id="services" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                2. الخدمات المقدمة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  نحن نقدم خدمات التسويق الرقمي التالية:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                    <span>متابعين حقيقيين ونشطين لجميع منصات التواصل الاجتماعي</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                    <span>لايكات وتفاعلات طبيعية وآمنة</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                    <span>مشاهدات عالية الجودة للفيديوهات</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                    <span>تعليقات مخصصة وذات معنى</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                    <span>مشاركات وريتويت لزيادة الانتشار</span>
                  </li>
                </ul>
                <p className="text-muted-foreground leading-relaxed">
                  جميع خدماتنا تتم بطرق آمنة ومتوافقة مع سياسات منصات التواصل الاجتماعي. نحن نضمن جودة الخدمة 
                  وسرعة التسليم وفقاً للمواعيد المحددة لكل خدمة.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* User Obligations */}
          <Card id="user-obligations" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-500" />
                3. التزامات المستخدم
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  عند استخدام خدماتنا، يجب عليك الالتزام بما يلي:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-500 mt-0.5" />
                    <span>تقديم معلومات صحيحة ودقيقة عند التسجيل</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-500 mt-0.5" />
                    <span>عدم مشاركة بيانات حسابك مع أطراف أخرى</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-500 mt-0.5" />
                    <span>استخدام الخدمات للأغراض المشروعة فقط</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-500 mt-0.5" />
                    <span>عدم محاولة اختراق أو إلحاق الضرر بالموقع</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-500 mt-0.5" />
                    <span>احترام حقوق الملكية الفكرية</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Payments */}
          <Card id="payments" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-yellow-500" />
                4. الدفع والاسترداد
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <h4 className="font-semibold text-foreground">سياسة الدفع:</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• يجب الدفع مقدماً قبل بدء تنفيذ أي خدمة</li>
                  <li>• نقبل التحويلات البنكية والمحافظ الإلكترونية</li>
                  <li>• الأسعار معروضة بالجنيه المصري وقابلة للتغيير</li>
                  <li>• لا توجد رسوم إضافية على المدفوعات</li>
                </ul>

                <h4 className="font-semibold text-foreground">سياسة الاسترداد:</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• يمكن طلب الاسترداد في حالة عدم تسليم الخدمة خلال الوقت المحدد</li>
                  <li>• لا يمكن الاسترداد بعد بدء تنفيذ الخدمة</li>
                  <li>• يتم معالجة طلبات الاسترداد خلال 3-7 أيام عمل</li>
                  <li>• في حالة النقص في الكمية المطلوبة، يتم تعويض الفرق أو الاسترداد الجزئي</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Prohibited Uses */}
          <Card id="prohibited" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                5. الاستخدامات المحظورة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  يُحظر استخدام خدماتنا في الحالات التالية:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                    <span>المحتوى المخالف للقوانين أو الآداب العامة</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                    <span>المحتوى الذي يحتوي على عنف أو كراهية</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                    <span>انتهاك حقوق الطبع والنشر</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                    <span>الحسابات المزيفة أو المضللة</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                    <span>الأنشطة التجارية غير المشروعة</span>
                  </li>
                </ul>
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                  <p className="text-red-600 dark:text-red-400 text-sm">
                    <strong>تحذير:</strong> في حالة اكتشاف أي استخدام محظور، سيتم إيقاف الخدمة فوراً دون استرداد.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Liability */}
          <Card id="liability" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-purple-500" />
                6. المسؤولية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  نحن نبذل قصارى جهدنا لتقديم خدمات عالية الجودة، ولكن:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• لا نتحمل مسؤولية أي أضرار قد تنتج عن استخدام خدماتنا</li>
                  <li>• لا نضمن النتائج المحددة أو الدائمة</li>
                  <li>• لا نتحمل مسؤولية تغييرات سياسات منصات التواصل الاجتماعي</li>
                  <li>• المستخدم مسؤول عن استخدام الخدمات وفقاً لقوانين بلده</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Privacy */}
          <Card id="privacy" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-500" />
                7. الخصوصية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  نحن نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• لا نشارك معلوماتك الشخصية مع أطراف ثالثة</li>
                  <li>• نستخدم بياناتك فقط لتقديم الخدمات المطلوبة</li>
                  <li>• نحمي بياناتك بأحدث تقنيات الأمان</li>
                  <li>• يمكنك طلب حذف بياناتك في أي وقت</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Changes */}
          <Card id="changes" className="glass-effect">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-orange-500" />
                8. التعديلات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  نحتفظ بالحق في تعديل هذه الشروط والأحكام في أي وقت. سيتم إشعارك بأي تغييرات مهمة عبر:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• إشعار على الموقع الإلكتروني</li>
                  <li>• رسالة بريد إلكتروني</li>
                  <li>• إشعار في حسابك الشخصي</li>
                </ul>
                <p className="text-muted-foreground leading-relaxed">
                  استمرارك في استخدام الخدمات بعد التعديلات يعني موافقتك على الشروط الجديدة.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card id="contact" className="glass-effect neon-glow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-primary" />
                9. التواصل
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  للاستفسارات أو الدعم الفني، يمكنك التواصل معنا عبر:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">صاحب السيرفر</h4>
                    <p className="text-primary font-medium">👑 alaa badeeh 👑</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">الدعم الفني</h4>
                    <p className="text-muted-foreground">نظام التذاكر داخل الموقع</p>
                  </div>
                </div>
                <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
                  <p className="text-primary text-sm">
                    <strong>ملاحظة:</strong> هذه الشروط سارية اعتباراً من تاريخ 11 يناير 2025. 
                    آخر تحديث: 11 يناير 2025.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Terms

