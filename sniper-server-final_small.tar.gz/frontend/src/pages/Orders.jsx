import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Search, 
  Filter,
  Package,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Eye,
  RefreshCw
} from 'lucide-react'

const Orders = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  const orders = [
    {
      id: 92537,
      service: 'متابعين إنستغرام عرب حقيقيين',
      link: 'https://instagram.com/example_account',
      quantity: 1000,
      charge: 15.00,
      startCount: 1250,
      remains: 0,
      status: 'Completed',
      progress: 100,
      createdAt: '2025-01-11 14:30:25',
      completedAt: '2025-01-11 15:45:12'
    },
    {
      id: 92536,
      service: 'لايكات فيسبوك سريعة',
      link: 'https://facebook.com/post/123456',
      quantity: 500,
      charge: 4.25,
      startCount: 89,
      remains: 125,
      status: 'In Progress',
      progress: 75,
      createdAt: '2025-01-11 16:15:30',
      completedAt: null
    },
    {
      id: 92535,
      service: 'مشاهدات يوتيوب عالية الجودة',
      link: 'https://youtube.com/watch?v=example',
      quantity: 5000,
      charge: 60.00,
      startCount: 2340,
      remains: 2750,
      status: 'In Progress',
      progress: 45,
      createdAt: '2025-01-11 12:20:15',
      completedAt: null
    },
    {
      id: 92534,
      service: 'ريتويت تويتر',
      link: 'https://twitter.com/user/status/123',
      quantity: 100,
      charge: 2.00,
      startCount: 45,
      remains: 0,
      status: 'Completed',
      progress: 100,
      createdAt: '2025-01-11 10:45:20',
      completedAt: '2025-01-11 11:30:45'
    },
    {
      id: 92533,
      service: 'متابعين تويتر عرب',
      link: 'https://twitter.com/example_user',
      quantity: 250,
      charge: 6.25,
      startCount: 890,
      remains: 250,
      status: 'Pending',
      progress: 0,
      createdAt: '2025-01-11 17:30:10',
      completedAt: null
    },
    {
      id: 92532,
      service: 'لايكات إنستغرام سريعة',
      link: 'https://instagram.com/p/example_post',
      quantity: 750,
      charge: 4.50,
      startCount: 156,
      remains: 0,
      status: 'Cancelled',
      progress: 0,
      createdAt: '2025-01-11 09:15:30',
      completedAt: null
    }
  ]

  const getStatusInfo = (status) => {
    switch (status) {
      case 'Completed':
        return { 
          label: 'مكتمل', 
          variant: 'default', 
          icon: CheckCircle, 
          color: 'text-green-500',
          bgColor: 'bg-green-500'
        }
      case 'In Progress':
        return { 
          label: 'قيد التنفيذ', 
          variant: 'secondary', 
          icon: Clock, 
          color: 'text-blue-500',
          bgColor: 'bg-blue-500'
        }
      case 'Pending':
        return { 
          label: 'في الانتظار', 
          variant: 'outline', 
          icon: AlertCircle, 
          color: 'text-yellow-500',
          bgColor: 'bg-yellow-500'
        }
      case 'Cancelled':
        return { 
          label: 'ملغي', 
          variant: 'destructive', 
          icon: XCircle, 
          color: 'text-red-500',
          bgColor: 'bg-red-500'
        }
      default:
        return { 
          label: status, 
          variant: 'secondary', 
          icon: AlertCircle, 
          color: 'text-gray-500',
          bgColor: 'bg-gray-500'
        }
    }
  }

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.id.toString().includes(searchTerm) ||
      order.service.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const stats = {
    total: orders.length,
    completed: orders.filter(o => o.status === 'Completed').length,
    inProgress: orders.filter(o => o.status === 'In Progress').length,
    pending: orders.filter(o => o.status === 'Pending').length
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground mb-2">طلباتي</h1>
        <p className="text-muted-foreground">تتبع جميع طلباتك وحالتها</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <Package className="w-8 h-8 text-primary mx-auto mb-2" />
            <div className="text-2xl font-bold text-foreground">{stats.total}</div>
            <div className="text-sm text-muted-foreground">إجمالي الطلبات</div>
          </CardContent>
        </Card>
        
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-500">{stats.completed}</div>
            <div className="text-sm text-muted-foreground">مكتملة</div>
          </CardContent>
        </Card>
        
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-500">{stats.inProgress}</div>
            <div className="text-sm text-muted-foreground">قيد التنفيذ</div>
          </CardContent>
        </Card>
        
        <Card className="glass-effect">
          <CardContent className="p-4 text-center">
            <AlertCircle className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-yellow-500">{stats.pending}</div>
            <div className="text-sm text-muted-foreground">في الانتظار</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="glass-effect">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث برقم الطلب أو اسم الخدمة..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              {['all', 'Completed', 'In Progress', 'Pending', 'Cancelled'].map((status) => (
                <Button
                  key={status}
                  variant={statusFilter === status ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setStatusFilter(status)}
                >
                  {status === 'all' ? 'الكل' : getStatusInfo(status).label}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.map((order) => {
          const statusInfo = getStatusInfo(order.status)
          const StatusIcon = statusInfo.icon
          
          return (
            <Card key={order.id} className="glass-effect hover:neon-glow transition-all">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  {/* Order Info */}
                  <div className="flex-1 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lg font-bold text-foreground">#{order.id}</span>
                          <Badge variant={statusInfo.variant} className={statusInfo.bgColor}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {statusInfo.label}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-foreground">{order.service}</h3>
                        <p className="text-sm text-muted-foreground break-all">{order.link}</p>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    {order.status === 'In Progress' && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">التقدم</span>
                          <span className="font-medium">{order.progress}%</span>
                        </div>
                        <Progress value={order.progress} className="h-2" />
                        <div className="text-xs text-muted-foreground">
                          متبقي: {order.remains.toLocaleString()} من {order.quantity.toLocaleString()}
                        </div>
                      </div>
                    )}

                    {/* Order Details */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">الكمية:</span>
                        <div className="font-medium">{order.quantity.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">التكلفة:</span>
                        <div className="font-medium text-primary">{order.charge} جنيه</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">العدد الأولي:</span>
                        <div className="font-medium">{order.startCount.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">تاريخ الطلب:</span>
                        <div className="font-medium">{order.createdAt}</div>
                      </div>
                    </div>

                    {order.completedAt && (
                      <div className="text-sm">
                        <span className="text-muted-foreground">تاريخ الإكمال:</span>
                        <span className="font-medium mr-2">{order.completedAt}</span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2 lg:w-32">
                    <Button variant="outline" size="sm" className="w-full">
                      <Eye className="w-4 h-4 mr-2" />
                      تفاصيل
                    </Button>
                    {order.status === 'In Progress' && (
                      <Button variant="outline" size="sm" className="w-full">
                        <RefreshCw className="w-4 h-4 mr-2" />
                        تحديث
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filteredOrders.length === 0 && (
        <Card className="glass-effect">
          <CardContent className="p-12 text-center">
            <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">لا توجد طلبات</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || statusFilter !== 'all' 
                ? 'لم يتم العثور على طلبات تطابق البحث'
                : 'لم تقم بأي طلبات بعد'
              }
            </p>
            <Button>
              <Package className="w-4 h-4 mr-2" />
              اطلب خدمة جديدة
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default Orders

