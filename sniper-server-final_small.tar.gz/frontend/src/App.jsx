import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState, useEffect } from 'react'
import './App.css'

// Components
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Home from './pages/Home'
import Services from './pages/Services'
import Orders from './pages/Orders'
import AddFunds from './pages/AddFunds'
import Tickets from './pages/Tickets'
import Profile from './pages/Profile'
import Terms from './pages/Terms'
import AdminPanel from './pages/AdminPanel'

function App() {
  const [isDark, setIsDark] = useState(true)
  const [user, setUser] = useState(null)

  useEffect(() => {
    // تطبيق الوضع المظلم افتراضياً
    document.documentElement.classList.toggle('dark', isDark)
  }, [isDark])

  const toggleTheme = () => {
    setIsDark(!isDark)
  }

  return (
    <Router>
      <div className={`min-h-screen ${isDark ? 'dark gradient-bg' : 'bg-background'}`}>
        <div className="flex">
          <Sidebar />
          <div className="flex-1 flex flex-col">
            <Header user={user} isDark={isDark} toggleTheme={toggleTheme} />
            <main className="flex-1 p-6">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/services" element={<Services />} />
                <Route path="/orders" element={<Orders />} />
                <Route path="/add-funds" element={<AddFunds />} />
                <Route path="/tickets" element={<Tickets />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/admin/x9k2m8n7q5w3" element={<AdminPanel />} />
              </Routes>
            </main>
          </div>
        </div>
      </div>
    </Router>
  )
}

export default App
