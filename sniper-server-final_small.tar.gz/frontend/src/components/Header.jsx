import { Bell, Sun, Moon, User, Wallet, Crown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useState, useEffect } from 'react'

const Header = ({ user, isDark, toggleTheme }) => {
  const [notifications, setNotifications] = useState(2);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), 500);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <header className="h-16 bg-card border-b border-border glass-effect flex items-center justify-between px-6 slide-in-up">
      {/* Welcome Message */}
      <div className="flex items-center gap-4">
        <div className="relative">
          <Crown className="w-8 h-8 text-yellow-400 floating" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-ping"></div>
        </div>
        <div>
          <h2 className="text-xl font-bold text-gradient">
            سيرفر القناص المتكامل
          </h2>
          <p className="text-sm text-muted-foreground">👑 alaa badeeh 👑</p>
        </div>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-4">
        {/* Balance */}
        <div className="flex items-center gap-2 bg-muted px-4 py-2 rounded-lg glass-effect card-hover">
          <Wallet className="w-4 h-4 text-primary pulse" />
          <span className="text-sm font-medium">الرصيد:</span>
          <span className="text-sm font-bold text-gradient">0.00 جنيه</span>
        </div>

        {/* Notifications */}
        <Button 
          variant="ghost" 
          size="icon" 
          className={`relative btn-hover-glow transition-all duration-300 ${
            isAnimating ? 'scale-110' : ''
          }`}
          onClick={() => setIsAnimating(!isAnimating)}
        >
          <Bell className={`w-5 h-5 ${isAnimating ? 'animate-bounce' : ''}`} />
          {notifications > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full text-xs flex items-center justify-center text-white animate-pulse">
              {notifications}
            </span>
          )}
        </Button>

        {/* Theme Toggle */}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleTheme}
          className="btn-hover-glow transition-all duration-500 hover:rotate-180"
        >
          {isDark ? (
            <Sun className="w-5 h-5 text-yellow-400" />
          ) : (
            <Moon className="w-5 h-5 text-blue-400" />
          )}
        </Button>

        {/* User Menu */}
        <Button variant="ghost" size="icon" className="btn-hover-glow relative">
          <User className="w-5 h-5" />
          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background"></div>
        </Button>
      </div>

      {/* Animated Progress Bar */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-muted overflow-hidden">
        <div className="h-full progress-bar" style={{ width: '75%' }}></div>
      </div>
    </header>
  )
}

export default Header

