import { Link, useLocation } from 'react-router-dom'
import { 
  Home, 
  ShoppingCart, 
  Package, 
  CreditCard, 
  MessageSquare, 
  User, 
  FileText,
  Target,
  Crown
} from 'lucide-react'

const Sidebar = () => {
  const location = useLocation()

  const menuItems = [
    { path: '/', icon: Home, label: 'الرئيسية' },
    { path: '/services', icon: ShoppingCart, label: 'الخدمات' },
    { path: '/orders', icon: Package, label: 'الطلبات' },
    { path: '/add-funds', icon: CreditCard, label: 'إضافة الأموال' },
    { path: '/tickets', icon: MessageSquare, label: 'التذاكر' },
    { path: '/profile', icon: User, label: 'الحساب' },
    { path: '/terms', icon: FileText, label: 'شروط الخدمة' },
  ]

  const isActive = (path) => location.pathname === path

  return (
    <div className="w-64 h-screen bg-card border-r border-border glass-effect">
      {/* Logo */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center neon-glow">
            <Target className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">سيرفر القناص</h1>
            <p className="text-sm text-muted-foreground">المتكامل</p>
          </div>
        </div>
      </div>

      {/* Owner Info */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-2 text-primary">
          <Crown className="w-4 h-4" />
          <span className="text-sm font-medium">alaa badeeh</span>
          <Crown className="w-4 h-4" />
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                    isActive(item.path)
                      ? 'bg-primary text-primary-foreground neon-glow'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="text-center text-xs text-muted-foreground">
          <p>© 2025 سيرفر القناص المتكامل</p>
          <p>جميع الحقوق محفوظة</p>
        </div>
      </div>
    </div>
  )
}

export default Sidebar

